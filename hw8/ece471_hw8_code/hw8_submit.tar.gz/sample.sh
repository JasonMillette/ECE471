#!/bin/sh

echo "Not another hello world program!"     #Prints message to command line
