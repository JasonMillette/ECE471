#define SENSOR_NAME "/sys/bus/w1/devices/28-0416563c6cff/w1_slave"
